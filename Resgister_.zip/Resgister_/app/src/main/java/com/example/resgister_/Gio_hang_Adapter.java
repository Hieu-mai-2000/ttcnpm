package com.example.resgister_;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class Gio_hang_Adapter extends BaseAdapter {
    private Context context;
    private int Layout;
    private List<class_gio_hang> foodList;


    public Gio_hang_Adapter(Context context, int layout, List<class_gio_hang> foodList) {
        this.context = context;
        Layout = layout;
        this.foodList = foodList;
    }

    @Override
    public int getCount() {
        return foodList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    //1 khi kéo giao diện mỗi lần sẽ ánh xạ nên tốn bộ nhớ
    //việc tạo hoder sẽ giúp làm giảm những view đã được ánh xạ không phải ánh xạ lại lần nữa
    private  class ViewHoder{
        ImageView imgHinh;
        TextView txtTen,txtMoTa;

    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        ViewHoder hoder;
        if(view == null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            view = inflater.inflate(Layout,null);
            hoder = new ViewHoder();
            //anh xa view
            hoder.txtTen = (TextView) view.findViewById(R.id.Gio_hang_ten_mon);
            hoder.txtMoTa = (TextView) view.findViewById(R.id.Gio_hang_ghi_chu);
            hoder.imgHinh = (ImageView) view.findViewById(R.id.Gio_hang_hinh_mon);


            view.setTag(hoder);
        }else{
            hoder = (ViewHoder) view.getTag();
        }


        //gan gia tri
        class_gio_hang food = foodList.get(i);

        hoder.txtTen.setText(food.getName());
        hoder.txtMoTa.setText(food.getDetail());
        hoder.imgHinh.setImageResource(food.getImage());

        //gan cái animation---->gán hiệu ứng
        Animation animation = AnimationUtils.loadAnimation(context,R.anim.scale_list_hieu_ung);
        view.startAnimation(animation);

        hoder.imgHinh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, "vo duoc roi ne", Toast.LENGTH_SHORT).show();
            }
        });


        return view;
    }
}
