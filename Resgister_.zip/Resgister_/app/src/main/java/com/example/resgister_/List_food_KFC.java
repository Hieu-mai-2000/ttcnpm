package com.example.resgister_;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class List_food_KFC extends AppCompatActivity {

    ListView lvFood;
    ArrayList<class_list_food> arrayFood;
    List_food_for_quay_hang_Adapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_food__k_f_c);

        anhxa();

        adapter = new List_food_for_quay_hang_Adapter(this,R.layout.list_food_for_quay_hang,arrayFood);
        lvFood.setAdapter(adapter);

        lvFood.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//                Intent intent = new Intent(List_food_KFC.this,Deatail_food.class);
//                intent.putExtra("class",arrayFood.get(i));
//                startActivity(intent);
                //Toast.makeText(List_food_KFC.this, arrayFood.get(i).getName(), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(List_food_KFC.this,Deatail_food.class);
                intent.putExtra("class",arrayFood.get(i));
//                switch (i){
//                    case 0:
//
//                        break;
//                    case 1:
//
//                        break;
//
//
//                }
                startActivity(intent);
            }
        });

    }


    //Dùng để tạo ra 1 cái menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_list_food,menu);
        return super.onCreateOptionsMenu(menu);
    }


    //Dùng để tác động vào menu bên góc bên phải phía trên
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
//        if(item.getItemId() == R.id.gio_hang_list_food){
//            Intent intent = new Intent(List_food_KFC.this,Gio_hang.class);
//            startActivity(intent);
//
//        }

        switch (item.getItemId()){
            case R.id.gio_hang_list_food_menu_list_food:
                Intent intent = new Intent(List_food_KFC.this,Gio_hang.class);
                startActivity(intent);
                break;
            case R.id.Home_menu_list_food:
                 intent = new Intent(List_food_KFC.this,quan_quay_hang.class);
                startActivity(intent);
                break;
            case R.id.menuShare_menu_list_food:
                Toast.makeText(this, "chưa có làm", Toast.LENGTH_SHORT).show();
                break;
            case R.id.personal_menu_list_food:
                Toast.makeText(this, "chưa có làm", Toast.LENGTH_SHORT).show();
                break;
            case R.id.menuSearch_menu_list_food:
                Toast.makeText(this, "chưa có làm", Toast.LENGTH_SHORT).show();
                break;
            case R.id.Love_menu_list_food:
                Toast.makeText(this, "chưa có làm", Toast.LENGTH_SHORT).show();
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    private void anhxa(){
        lvFood = (ListView) findViewById(R.id.ListFood);
        arrayFood = new ArrayList<>();

        arrayFood.add(new class_list_food("Gà rán","được chiên giòn hòa tan vào trong khoan miệng",R.drawable.list_food_ga_ran,1500,4));
       arrayFood.add(new class_list_food("Combo quyền thoại","Combo hút máu người ăn bằng tính toán của nhà sản xuất",R.drawable.list_food_combo,12000,15));
       arrayFood.add(new class_list_food("bánh sầu riêng","Bánh tự chế ăn được hay không thì không biết",R.drawable.list_food_banh_sau_rieng,45000,23));
        arrayFood.add(new class_list_food("Gà trứng","Khi gà đẻ có trứng thì lấy trứng đó chiên luôn",R.drawable.list_food_ga_trung,43000,2));
        arrayFood.add(new class_list_food("Khoai Tây","Khoai tây huyền thoại,thần thánh",R.drawable.list_food_khoai_tay,23000,23));


    }
}