package com.example.resgister_;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

public class Deatail_food extends AppCompatActivity {

TextView name,detail,gia,soluong;
ImageView hinh;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deatail_food);

        anhxa();

        Dong_bo_du_lieu();

    }

    //hiển thị menu ở góc trên bên phải
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_quay_hang,menu);
        return super.onCreateOptionsMenu(menu);

    }
    //dùng để tác động được vào phần menu

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.gio_hang_list_food){
            Intent intent = new Intent(Deatail_food.this,Gio_hang.class);
            startActivity(intent);

        }
        return super.onOptionsItemSelected(item);
    }



    private void anhxa(){
        name = (TextView) findViewById(R.id.Deatail_food_mon_an);
        hinh = (ImageView) findViewById(R.id.Deatail_food_hinh_mon_an);
        detail = (TextView) findViewById(R.id.Deatail_food_chi_tiet_mon_an);
        gia = (TextView) findViewById(R.id.Deatail_food_gia);
        soluong = (TextView) findViewById(R.id.Deatail_food_so_luong);

    }

    private void Dong_bo_du_lieu(){
        Intent intent = getIntent();
        class_list_food list_food_for_quay_hang = (class_list_food) intent.getSerializableExtra("class");
        hinh.setImageResource(list_food_for_quay_hang.getImage());
        name.setText(list_food_for_quay_hang.getName());
        detail.setText(list_food_for_quay_hang.getDetail());
        gia.setText(list_food_for_quay_hang.getGia()+"");
        soluong.setText(list_food_for_quay_hang.getNumber()+"");

    }




}