package com.example.resgister_;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Gio_hang extends AppCompatActivity {
    Button TienHangDatMon;
    ListView lvGioHang;
    ArrayList<class_gio_hang> arrayGioHang;
    Gio_hang_Adapter adapter;
    int vi_tri=0;
   // TextView gio_hang_ghi_chu;
    TextView them_ghi_chu;//biến nằm ở giỏ hàng ghi chú


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gio_hang);

        anhxa();
        Adapter();


        TienHangDatMon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Gio_hang.this,Chi_tiet_don_hang.class);
                startActivity(intent);
            }
        });


    }

    private void anhxa(){

        them_ghi_chu = (TextView) findViewById(R.id.Gio_hang_ghi_chu);
        TienHangDatMon = (Button) findViewById(R.id.activity_tienhangdatmon_gio_hang);
        lvGioHang = (ListView) findViewById(R.id.Gio_hang_ListView);
        arrayGioHang = new ArrayList<>();

        arrayGioHang.add(new class_gio_hang("Gà rán","được chiên giòn hòa tan vào trong khoan miệng",R.drawable.list_food_ga_ran));
        arrayGioHang.add(new class_gio_hang("Combo quyền thoại","Combo hút máu người ăn bằng tính toán của nhà sản xuất",R.drawable.list_food_combo));
        arrayGioHang.add(new class_gio_hang("bánh sầu riêng","Bánh tự chế ăn được hay không thì không biết",R.drawable.list_food_banh_sau_rieng));
        arrayGioHang.add(new class_gio_hang("Gà trứng","Khi gà đẻ có trứng thì lấy trứng đó chiên luôn",R.drawable.list_food_ga_trung));
        arrayGioHang.add(new class_gio_hang("Khoai Tây","Khoai tây huyền thoại,thần thánh",R.drawable.list_food_khoai_tay));


    }


    //khai báo context menu
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {

        getMenuInflater().inflate(R.menu.menu_context_nhan_lau_hien_bang,menu);

        super.onCreateContextMenu(menu, v, menuInfo);
    }

    //bắt sự kiện trong context menu


    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case R.id.menu_context_ghi_chu:
                final Dialog dialog = new Dialog(Gio_hang.this);
                dialog.setTitle("sdjkfjdk");
               // dialog.setTitle("Hộp thoại xử lý");
                dialog.setCancelable(false);
                dialog.setContentView(R.layout.box_them_ghi_chu);
                final EditText edt_ghi_chu = (EditText)dialog.findViewById(R.id.box_them_gc_Them_ghi_chu);
                Button nut_huy = (Button)dialog.findViewById(R.id.box_them_gc_huy);
                Button nut_them = (Button)dialog.findViewById(R.id.box_them_gc_them);
                nut_them.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        //gửi ghi chú qua cho
                        them_ghi_chu = (TextView) findViewById(R.id.Gio_hang_ghi_chu);
                        them_ghi_chu.setText(edt_ghi_chu.getText().toString().trim());


                        dialog.cancel();
                    }
                });
                nut_huy.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.cancel();
                    }
                });
                dialog.show();
                break;
            case R.id.menu_context_them_mon:
                Toast.makeText(this, "chưa có làm", Toast.LENGTH_SHORT).show();
                break;
            case R.id.menu_context_xoa_mon:
                arrayGioHang.remove(vi_tri);
                adapter.notifyDataSetChanged();
                break;
        }
        return super.onContextItemSelected(item);
    }

    private void Adapter(){
        adapter = new Gio_hang_Adapter(this,R.layout.adapter_gio_hang,arrayGioHang);

        lvGioHang.setAdapter(adapter);

        lvGioHang.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {


                registerForContextMenu(view); //Resgister cho context menu khi sử dụng
                vi_tri=i;

                //Toast.makeText(Gio_hang.this, "Đã được rồi nè", Toast.LENGTH_SHORT).show();
                return false;
            }
        });

        // hiệu ứng khi click vào danh sách
//        lvGioHang.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//                //chạm vào sẽ hiện tên lên
//                Toast.makeText(Gio_hang.this,"kdjfkdj", Toast.LENGTH_SHORT).show();
//                arrayGioHang.remove(i);
//                adapter.notifyDataSetChanged();
//
//                //khi nhấn vô quầy hàng KFC thì list_food_KFC sẽ được mở lên
//
//
//            }
//        });
    }
}