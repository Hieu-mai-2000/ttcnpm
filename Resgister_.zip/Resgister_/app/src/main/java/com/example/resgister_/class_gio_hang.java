package com.example.resgister_;

import android.media.Image;
import android.widget.Button;

import java.io.Serializable;

public class class_gio_hang implements Serializable {
    private  String name;
    private String Detail;
    private int Image,gia,number;
    String ghi_chu;

    public String getGhi_chu() {
        return ghi_chu;
    }

    public void setGhi_chu(String ghi_chu) {
        this.ghi_chu = ghi_chu;
    }

    public class_gio_hang(String name, String detail, int image, int gia, int number, String ghi_chu) {
        this.name = name;
        Detail = detail;
        Image = image;
        this.gia = gia;
        this.number = number;
        this.ghi_chu = ghi_chu;
    }

    public class_gio_hang(String name, String detail, int image, int gia, int number) {
        this.name = name;
        Detail = detail;
        Image = image;
        this.gia = gia;
        this.number = number;
    }

    public class_gio_hang(String name, String detail, int image) {
        this.name = name;
        Detail = detail;
        Image = image;
    }

    public int getGia() {
        return gia;
    }

    public void setGia(int gia) {
        this.gia = gia;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDetail() {
        return Detail;
    }

    public void setDetail(String detail) {
        Detail = detail;
    }

    public int getImage() {
        return Image;
    }

    public void setImage(int image) {
        Image = image;
    }

}
