package com.example.resgister_;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Chi_tiet_don_hang extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chi_tiet_don_hang);
    }
}