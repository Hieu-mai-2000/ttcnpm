package com.example.resgister_;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button Dangky,login;
    EditText email,password;
    CheckBox cbRemember;
    String Email="" , PassWord="";//chuỗi dùng để lấy dữ liệu trả về từ "đăng ký"

    SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //dung de luu tru gia tri

        anhxa();

        //nếu có dữ liệu trả về từ "đăng ký"
        Intent intent = getIntent();
         Email = intent.getStringExtra("Email");
         PassWord = intent.getStringExtra("PassWord");

        //taọ vùng dữ liệu lưu giá trị
        sharedPreferences = getSharedPreferences("dataLogin",MODE_PRIVATE);

        //lấy giá trị sharePreferences
        //chuỗi 1 là tên mình đặt chuỗi 2 là rỗng vì có thể lúc đầu người dùng chưa nhập gi
        email.setText(sharedPreferences.getString("taikhoan", Email));
        password.setText(sharedPreferences.getString("matkhau",PassWord));
        cbRemember.setChecked(sharedPreferences.getBoolean("checked",false));

        //bấm vào nút đăng ký tài khoản
        Dangky.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    //hiện ra giao diện đăng ký tài khoản

                    Intent intent = new Intent(MainActivity.this, second.class);
                    startActivity(intent);

            }
        });


        //bấm vào nút đăng nhập tài khoản
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = email.getText().toString();
                String pass = password.getText().toString();

                /*dùng để kiểm tra khi thoát ra vẫn lưu giá trị*/
                if(username.equals("123@gmail.com") && pass.equals("123")) {
                    if(cbRemember.isChecked()){
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("taikhoan",username);//lưu biến String vừa tạo ở trên
                        editor.putString("matkhau",pass);//lưu biến String vừa tạo ở trên
                        editor.putBoolean("checked",true);
                        editor.commit();
                    }else {
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.remove("taikhoan");
                        editor.remove("matkhau");
                        editor.remove("checked");
                        editor.commit();

                    }

                //hiện ra giao diện quay_hang
                Intent intent = new Intent(MainActivity.this,quan_quay_hang.class);
                startActivity(intent);
                //hiệu ứng chuyển cảnh qua lại
                overridePendingTransition(R.anim.anim_enter,R.anim.anim_exit);
                //overridePendingTransition(R.anim.chuyen_tu_phai_qua_trai_enter,R.anim.chuyen_tu_phai_qua_trai_exit);
                }else {
                    Toast.makeText(MainActivity.this, "Đăng nhập thất bại", Toast.LENGTH_SHORT).show();
                }
                /*kết thúc phần lưu giá trị*/
            }
        });

    }
    private void anhxa(){
        Dangky = (Button) findViewById(R.id.Main_register);
        login =(Button)findViewById(R.id.Main_login);
        email = (EditText) findViewById(R.id.Main_Email);
        password = (EditText) findViewById(R.id.Main_Password);
        cbRemember = (CheckBox) findViewById(R.id.Main_checkBox);
    }


}