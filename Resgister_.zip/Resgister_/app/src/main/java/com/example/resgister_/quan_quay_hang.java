package com.example.resgister_;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;

public class quan_quay_hang extends AppCompatActivity {

    GridView gvHinhAnh;
    ArrayList<class_quay_hang> arrayImage;
    quay_hang_Adapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quan_quay_hang);


        anhxa();//khai báo ánh xạ là sẽ dùng các biến này
        Adapter();//thể hiện danh sách các quầy hàng


    }

    //hiển thị menu ở góc trên bên phải
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_quay_hang,menu);
        return super.onCreateOptionsMenu(menu);

    }
    //dùng để tác động được vào phần menu


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.gio_hang_list_food){
            Intent intent = new Intent(quan_quay_hang.this,Gio_hang.class);
            startActivity(intent);

        }
        return super.onOptionsItemSelected(item);
    }

    private  void anhxa(){
        gvHinhAnh = (GridView) findViewById(R.id.gridview);
        arrayImage = new ArrayList<>();
        arrayImage.add(new class_quay_hang("Burger King",R.drawable.quay_hang_burger_king));
        arrayImage.add(new class_quay_hang("JolliBee",R.drawable.quay_hang_jollibbee));
        arrayImage.add(new class_quay_hang("KFC",R.drawable.quay_hang_kfc));
        arrayImage.add(new class_quay_hang("MCdonald",R.drawable.quay_hang_mcdonal));
        arrayImage.add(new class_quay_hang("Pizza Hut",R.drawable.quay_hang_pizza_hut));
        arrayImage.add(new class_quay_hang("BBQ chicken",R.drawable.quay_hang_bbq));



    }

    private void Adapter(){
        adapter = new quay_hang_Adapter(this,R.layout.quay_hang,arrayImage);

        gvHinhAnh.setAdapter(adapter);

        gvHinhAnh.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //chạm vào sẽ hiện tên lên
                //Toast.makeText(quan_quay_hang.this,arrayImage.get(i).getTen(), Toast.LENGTH_SHORT).show();

                //khi nhấn vô quầy hàng KFC thì list_food_KFC sẽ được mở lên
                if(i == 2){
                    Intent intent = new Intent(quan_quay_hang.this,List_food_KFC.class);
                    startActivity(intent);
                    //hiệu ứng chuyển cảnh qua lại
                   // overridePendingTransition(R.anim.anim_enter,R.anim.anim_exit);
                    overridePendingTransition(R.anim.chuyen_tu_phai_qua_trai_enter,R.anim.chuyen_tu_phai_qua_trai_exit);
                }

            }
        });
    }
}