package com.example.test_quay;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class login_activity extends AppCompatActivity {
    Button Dangky,Login;
    EditText email,password;
    CheckBox cbRemember;
    String Email="" , PassWord="";//chuỗi dùng để lấy dữ liệu trả về từ "đăng ký"

    ArrayList<String> check_email = new ArrayList<String>();
    ArrayList<String> check_password = new ArrayList<String>();
    private  static String URL_LOGIN ="http://10.228.196.129:1234/orderfood/Person/loginCustomer.php";
    String urlInsert = "http://10.228.196.129:1234/orderfood/Person/checkInFor.php";


    SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_activity);


        //dung de luu tru gia tri

        anhxa();
        //GetDataImforCustomer(urlInsert);
       // Log.d("aaa",check_email);
        //Log.d("timkiem",check_email.get(0)+"");
      //  Log.d("timkiem",check_email.get(0));
     //   Toast.makeText(this, check_email.get(0), Toast.LENGTH_SHORT).show();
        if(check_email == null){
            Toast.makeText(this, "sai cho nao roi", Toast.LENGTH_SHORT).show();
        }

        //nếu có dữ liệu trả về từ "đăng ký"
        Intent intent = getIntent();
        Email = intent.getStringExtra("Email");
        PassWord = intent.getStringExtra("PassWord");

        //taọ vùng dữ liệu lưu giá trị
        sharedPreferences = getSharedPreferences("dataLogin", MODE_PRIVATE);

        //lấy giá trị sharePreferences
        //chuỗi 1 là tên mình đặt chuỗi 2 là rỗng vì có thể lúc đầu người dùng chưa nhập gi
        email.setText(sharedPreferences.getString("taikhoan", Email));
        password.setText(sharedPreferences.getString("matkhau", PassWord));
        cbRemember.setChecked(sharedPreferences.getBoolean("checked", false));


        //bấm vào nút đăng ký tài khoản
        Dangky.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


//                SharedPreferences.Editor editor = sharedPreferences.edit();
//                editor.remove("taikhoan");
//                editor.remove("matkhau");
//                editor.remove("checked");
//                editor.commit();
                //hiện ra giao diện đăng ký tài khoản

                Intent intent = new Intent(login_activity.this, register_activity.class);
                startActivity(intent);

            }
        });

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = email.getText().toString();
                String pass = password.getText().toString();

                /*dùng để kiểm tra khi thoát ra vẫn lưu giá trị*/
                if (username.equals("123@gmail.com") && pass.equals("123")) {
                    if (cbRemember.isChecked()) {
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("taikhoan", username);//lưu biến String vừa tạo ở trên
                        editor.putString("matkhau", pass);//lưu biến String vừa tạo ở trên
                        editor.putBoolean("checked", true);
                        editor.commit();
                    } else {
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.remove("taikhoan");
                        editor.remove("matkhau");
                        editor.remove("checked");
                        editor.commit();

                    }

                    //hiện ra giao diện quay_hang
                    Intent intent = new Intent(login_activity.this, MainActivity.class);
                    startActivity(intent);
                    //hiệu ứng chuyển cảnh qua lại
                    overridePendingTransition(R.anim.anim_enter, R.anim.anim_exit);
                    //overridePendingTransition(R.anim.chuyen_tu_phai_qua_trai_enter,R.anim.chuyen_tu_phai_qua_trai_exit);
                } else {
                    Toast.makeText(login_activity.this, "Đăng nhập thất bại", Toast.LENGTH_SHORT).show();
                }
                /*kết thúc phần lưu giá trị*/
            }
        });

//        Login.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//           // login(URL_LOGIN);
//                String mEmail = email.getText().toString().trim();
//                String mpassword = password.getText().toString().trim();
//                if(!mEmail.isEmpty()  || !mpassword.isEmpty()){
//                    LoginCustomer(mEmail,mpassword);
//                }else {
//                    Toast.makeText(login_activity.this, "khong duoc de trong", Toast.LENGTH_SHORT).show();
//                    return;
//                }
//            }
//        });
//        email.setText("hieu");////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//        password.setText("sdfjas");


    }

            //bấm vào nút đăng nhập tài khoản



        private void anhxa(){
            Dangky = (Button) findViewById(R.id.Main_register);
            Login = (Button) findViewById(R.id.Main_login);
            email = (EditText) findViewById(R.id.Main_Email);
            password = (EditText) findViewById(R.id.Main_Password);
            cbRemember = (CheckBox) findViewById(R.id.Main_checkBox);
        }

//    private void GetDataImforCustomer(String url){
//
//        RequestQueue requestQueue = Volley.newRequestQueue(this);
//        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
//                new Response.Listener<JSONArray>() {
//                    @Override
//                    public void onResponse(JSONArray response) {
//                        check_email.clear();
//                        check_password.clear();
//                        for(int i =0 ;i<response.length();i++){
//                            try {
//                                JSONObject object = response.getJSONObject(i);
//                                check_email.add(object.getString("emailCustomer"));
//                                check_password.add(object.getString("passwordCustomer"));
//                            } catch (JSONException e) {
//                                e.printStackTrace();
//                            }
//                        }
//                        //.notifyDataSetChanged();
//
//                    }
//                },
//                new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        Toast.makeText(login_activity.this, error.toString(), Toast.LENGTH_SHORT).show();
//                    }
//                }
//        );
//        //Toast.makeText(this, check_email.get(0), Toast.LENGTH_SHORT).show();
//        requestQueue.add(jsonArrayRequest);
//
//    }


//    private  void LoginCustomer(final String email_ , final String passWord_){
//        Login.setVisibility(View.GONE);
//
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_LOGIN,
//                new Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//                             if(response.contains("9")){
//                                 Toast.makeText(login_activity.this,"email khong dung", Toast.LENGTH_SHORT).show();
//                            }
//                        if(response.contains("6")){
//                            Toast.makeText(login_activity.this,"6666666666", Toast.LENGTH_SHORT).show();
//                        }
//                        if(response.contains("0")){
//                            Toast.makeText(login_activity.this,"000000", Toast.LENGTH_SHORT).show();
//                        }
//                        if(response.contains("3")){
//                            Toast.makeText(login_activity.this,"3333", Toast.LENGTH_SHORT).show();
//                        }
//                    }
//                },
//                new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        Login.setVisibility(View.VISIBLE);
//                        Toast.makeText(login_activity.this, "Error: kết nối"+error.toString(), Toast.LENGTH_SHORT).show();
//                    }
//                }
//        ){
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//                Map<String,String> params = new HashMap<>();
//                params.put("email",email_);
//                params.put("password",passWord_);
//                return params;
//            }
//        };
//        RequestQueue requestQueue = Volley.newRequestQueue(this);
//        requestQueue.add(stringRequest);
//
//
//    }

//    private void login(String url) {
//        StringRequest request = new StringRequest(Request.Method.POST, url,
//                new Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//                        if(response.contains("1")){
//                            Toast.makeText(login_activity.this, "Dang ky thanh cong", Toast.LENGTH_SHORT).show();
//
//                        }else{
//                            Toast.makeText(login_activity.this, "dang ky that bai", Toast.LENGTH_SHORT).show();
//
//                        }
//
//
//
//                    }
//                },
//                new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//
//                        Toast.makeText(login_activity.this, "that bai", Toast.LENGTH_SHORT).show();
//
//                    }
//                }){
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//                Map<String,String> params = new HashMap<>();
//                params.put("usermane",email.getText().toString());
//                params.put("password",password.getText().toString());
//                return params;
//            }
//        };
//
//        Volley.newRequestQueue(this).add(request);
//
//    }

}