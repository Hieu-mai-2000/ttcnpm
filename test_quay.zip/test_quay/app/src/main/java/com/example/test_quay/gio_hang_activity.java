package com.example.test_quay;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class gio_hang_activity extends AppCompatActivity {

    Button ThanhToan;
    ListView lvGioHang;
    ArrayList<class_gio_hang> arrayGioHang;
    Adapter_gio_hang adapter;
    int vi_tri=0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gio_hang_activity);

        anhxa();


       // Adapter();


//        TienHangDatMon.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(Gio_hang.this,Chi_tiet_don_hang.class);
//                startActivity(intent);
//            }
//        });


        ThanhToan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(gio_hang_activity.this, "thanh toán bằng gì,và xác nhận", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void anhxa(){

        ThanhToan = (Button) findViewById(R.id.gio_hang_thanh_toan);
        lvGioHang = (ListView) findViewById(R.id.gio_hang_listview_ordered);
        arrayGioHang = new ArrayList<>();
        Intent intent = getIntent();
        Bundle bundle = intent.getBundleExtra("truyen_du_lieu");
        String chuoi = bundle.getString("truyen_hinh");
        int soluong  =bundle.getInt("truyen_soluong_dat",123);
        int giatien  =bundle.getInt("truyen_gia_tien",123);
        class_gio_hang gio_hang = (class_gio_hang) bundle.getSerializable("truyen_doi_tuong");



        arrayGioHang.add(gio_hang);



//        arrayGioHang = intent.getParcelableArrayListExtra("food_in_gio_hang");
//        if(arrayGioHang == null){
//            Toast.makeText(this, "lam sai o dau do roi", Toast.LENGTH_SHORT).show();
//        }

        //bị một cái bug là click vào thì sự kiện được cập nhập vào giỏ hàng


        adapter = new Adapter_gio_hang(this,R.layout.element_gio_hang,arrayGioHang);

        lvGioHang.setAdapter(adapter);
    }


//    //khai báo context menu
//    @Override
//    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
//
//        getMenuInflater().inflate(R.menu.menu_context_nhan_lau_hien_bang,menu);
//
//        super.onCreateContextMenu(menu, v, menuInfo);
//    }
//
//    //bắt sự kiện trong context menu
//
//
//    @Override
//    public boolean onContextItemSelected(@NonNull MenuItem item) {
//
//        switch (item.getItemId()){
//            case R.id.menu_context_ghi_chu:
//                final Dialog dialog = new Dialog(Gio_hang.this);
//                dialog.setTitle("sdjkfjdk");
//                // dialog.setTitle("Hộp thoại xử lý");
//                dialog.setCancelable(false);
//                dialog.setContentView(R.layout.box_them_ghi_chu);
//                final EditText edt_ghi_chu = (EditText)dialog.findViewById(R.id.box_them_gc_Them_ghi_chu);
//                Button nut_huy = (Button)dialog.findViewById(R.id.box_them_gc_huy);
//                Button nut_them = (Button)dialog.findViewById(R.id.box_them_gc_them);
//                nut_them.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//
//                        //gửi ghi chú qua cho
//                        them_ghi_chu = (TextView) findViewById(R.id.Gio_hang_ghi_chu);
//                        them_ghi_chu.setText(edt_ghi_chu.getText().toString().trim());
//
//                        dialog.cancel();
//                    }
//                });
//                nut_huy.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        dialog.cancel();
//                    }
//                });
//                dialog.show();
//                break;
//            case R.id.menu_context_them_mon:
//                Toast.makeText(this, "chưa có làm", Toast.LENGTH_SHORT).show();
//                break;
//            case R.id.menu_context_xoa_mon:
//                arrayGioHang.remove(vi_tri);
//                adapter.notifyDataSetChanged();
//                break;
//        }
//        return super.onContextItemSelected(item);
//    }

//    private void Adapter(){
//        adapter = new Adapter_gio_hang(this,R.layout.element_gio_hang,arrayGioHang);
//
//        lvGioHang.setAdapter(adapter);
//
////        lvGioHang.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
////            @Override
////            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
////
////
////                registerForContextMenu(view); //Resgister cho context menu khi sử dụng
////                vi_tri=i;
////
////                //Toast.makeText(Gio_hang.this, "Đã được rồi nè", Toast.LENGTH_SHORT).show();
////                return false;
////            }
////        });
//
//        // hiệu ứng khi click vào danh sách
//        lvGioHang.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//                //chạm vào sẽ hiện tên lên
//                Toast.makeText(Gio_hang.this,"kdjfkdj", Toast.LENGTH_SHORT).show();
//                arrayGioHang.remove(i);
//                adapter.notifyDataSetChanged();
////
////                //khi nhấn vô quầy hàng KFC thì list_food_KFC sẽ được mở lên
////
////
////            }
////        });
//    }
//

}