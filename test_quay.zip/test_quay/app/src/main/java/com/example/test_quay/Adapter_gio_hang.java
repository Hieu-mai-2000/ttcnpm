package com.example.test_quay;

import android.content.Context;
import android.view.Choreographer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class Adapter_gio_hang extends BaseAdapter {
    private Context context;
    private int Layout;
    private List<class_gio_hang> gio_hang; //= new ArrayList<>();


    public Adapter_gio_hang(Context context, int layout, List<class_gio_hang> gio_hang) {
        this.context = context;
        Layout = layout;
        this.gio_hang = gio_hang;
    }

    @Override
    public int getCount() {
        return gio_hang.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    //1 khi kéo giao diện mỗi lần sẽ ánh xạ nên tốn bộ nhớ
    //việc tạo hoder sẽ giúp làm giảm những view đã được ánh xạ không phải ánh xạ lại lần nữa
    private  class ViewHoder{
        ImageView hinhmon,hinhNutTang,hinhNutGiam;
        TextView tenmon,tongTienmonan;
        EditText ghichu,somondat;

    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        ViewHoder hoder;
        if(view == null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            view = inflater.inflate(Layout,null);
            hoder = new ViewHoder();
            //anh xa view
            hoder.tenmon = (TextView) view.findViewById(R.id.element_gio_hang_ten_mon);
            hoder.tongTienmonan = (TextView) view.findViewById(R.id.element_gio_hang_total_raise_mon);
            hoder.hinhNutTang = (ImageView) view.findViewById(R.id.element_gio_hang_image_tang);
            hoder.hinhNutGiam = (ImageView) view.findViewById(R.id.element_gio_hang_image_tru);
            hoder.hinhmon = (ImageView) view.findViewById(R.id.element_gio_hang_hinh_mon);
            hoder.ghichu = (EditText) view.findViewById(R.id.element_gio_hang_ghi_chu);
            hoder.somondat = (EditText) view.findViewById(R.id.element_gio_hang_so_luong_dat);


            view.setTag(hoder);
        }else{
            hoder = (ViewHoder) view.getTag();
        }


        //gan gia tri
        class_gio_hang food = gio_hang.get(i);


        Picasso.get().load(food.getHinhmon()).into(hoder.hinhmon);
        hoder.tenmon.setText(food.getTenmon());
       // hoder.tongTienmonan.setText(food.getDetail();

//        //gan cái animation---->gán hiệu ứng
//        Animation animation = AnimationUtils.loadAnimation(context,R.anim.scale_list_hieu_ung);
//        view.startAnimation(animation);

//        hoder.imgHinh.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Toast.makeText(context, "vo duoc roi ne", Toast.LENGTH_SHORT).show();
//            }
//        });


        return view;
    }
}
