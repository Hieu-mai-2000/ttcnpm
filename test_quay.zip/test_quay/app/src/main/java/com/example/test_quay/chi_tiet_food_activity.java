package com.example.test_quay;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.security.identity.DocTypeNotSupportedException;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class chi_tiet_food_activity extends AppCompatActivity {


    ImageView image_monan,image_nut_tang,image_nut_giam;
    TextView tenmon,mota,gia,soluong;
    EditText ghichu,orderfoodED;
    Button datHang;
    ArrayList<class_gio_hang> arrayGioHang = new ArrayList<class_gio_hang>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chi_tiet_food_activity);

        anhxa();
        dong_bo_du_lieu();

        Intent intent = getIntent();
        final class_list_food listFood = (class_list_food) intent.getSerializableExtra("class");
        datHang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                class_gio_hang gio_hang = new class_gio_hang("https://covid19.lacounty.gov/wp-content/uploads/GettyImages-1128687123-1024x683.jpg",listFood.getSoluong(),listFood.getGia(),listFood.getTenmon(),"sdfd");
                Intent intent_thu_hai = new Intent(chi_tiet_food_activity.this,gio_hang_activity.class);

//                intent.putParcelableArrayListExtra("food_gio_hang", arrayGioHang);
//                if(arrayGioHang == null){
//                    Toast.makeText(chi_tiet_food_activity.this, "fffff", Toast.LENGTH_SHORT).show();
//                }else{
//                    Toast.makeText(chi_tiet_food_activity.this, "sdfd", Toast.LENGTH_SHORT).show();
//                }
                Bundle bundle = new Bundle();
                bundle.putInt("truyen_soluong_dat",listFood.getSoluong());
                bundle.putString("truyen_hinh",listFood.getHinhanh());
                bundle.putInt("truyen_gia_tien",listFood.getGia());
                bundle.putSerializable("truyen_doi_tuong",gio_hang);
                intent_thu_hai.putExtra("truyen_du_lieu",bundle);
                startActivity(intent_thu_hai);

            }
        });
    }

    private void anhxa(){

       // arrayGioHang = new ArrayList<>();

        image_monan         =(ImageView) findViewById(R.id.activity_CHiTietFood_hinhanh_food);
        image_nut_tang      =(ImageView) findViewById(R.id.activity_CHiTietFood_image_tang);
        image_nut_giam      =(ImageView) findViewById(R.id.activity_CHiTietFood_image_giam);
        tenmon              =(TextView) findViewById(R.id.activity_CHiTietFood_ten_mon);
        mota                =(TextView) findViewById(R.id.activity_CHiTietFood_mo_ta);
        gia                 =(TextView) findViewById(R.id.activity_CHiTietFood_gia_tien);
        soluong             =(TextView) findViewById(R.id.activity_CHiTietFood_food_con_lai);
        ghichu              = (EditText) findViewById(R.id.activity_CHiTietFood_ghi_chu);
        orderfoodED         = (EditText) findViewById(R.id.activity_CHiTietFood_number_order);
        datHang             = (Button) findViewById(R.id.activity_CHiTietFood_dat_hang);
    }

    private void dong_bo_du_lieu(){
        Intent intent = getIntent();
        class_list_food listFood = (class_list_food) intent.getSerializableExtra("class");
        Picasso.get().load(listFood.getHinhanh()).into(image_monan);
        tenmon.setText(listFood.getTenmon());
        //mota.setText(); chua co them vo
        gia.setText(listFood.getGia()+"");
        soluong.setText(listFood.getSoluong()+"");
        ghichu.setText("day la ghi chu chua duoc lam");
        orderfoodED.setText("9");

    }

    //hiển thị menu ở góc trên bên phải
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_quay_hang,menu);
        return super.onCreateOptionsMenu(menu);

    }
    //dùng để tác động được vào phần menu
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.gio_hang_list_food){
            Intent intent = new Intent(chi_tiet_food_activity.this,gio_hang_activity.class);
            startActivity(intent);

        }
        return super.onOptionsItemSelected(item);
    }
}