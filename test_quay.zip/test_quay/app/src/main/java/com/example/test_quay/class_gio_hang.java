package com.example.test_quay;

import android.os.Parcel;
import android.os.Parcelable;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.Serializable;

public class class_gio_hang implements Serializable {
    private int somondat,tongTienmonan;
    private String tenmon,ghichu;
    private String hinhmon;

    public class_gio_hang(String hinhmon, int somondat, int tongTienmonan, String tenmon, String ghichu) {
        this.hinhmon = hinhmon;
        this.somondat = somondat;
        this.tongTienmonan = tongTienmonan;
        this.tenmon = tenmon;
        this.ghichu = ghichu;
    }



    public String getHinhmon() {
        return hinhmon;
    }

    public void setHinhmon(String hinhmon) {
        this.hinhmon = hinhmon;
    }

    public int getSomondat() {
        return somondat;
    }

    public void setSomondat(int somondat) {
        this.somondat = somondat;
    }

    public int getTongTienmonan() {
        return tongTienmonan;
    }

    public void setTongTienmonan(int tongTienmonan) {
        this.tongTienmonan = tongTienmonan;
    }

    public String getTenmon() {
        return tenmon;
    }

    public void setTenmon(String tenmon) {
        this.tenmon = tenmon;
    }

    public String getGhichu() {
        return ghichu;
    }

    public void setGhichu(String ghichu) {
        this.ghichu = ghichu;
    }
}
